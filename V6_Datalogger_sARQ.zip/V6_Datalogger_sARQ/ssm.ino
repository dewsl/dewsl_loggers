void getSSMData() {   // mod/add parameters/function if needed
  debugPrintln("Add SSM-related functions here...");
  // AUX_TRIG -> switch for SSM supply
  // _globalSMSDump -> global data container
  // addToSMSStack(dataSegment) -> Use this to add individual segments to _globalSMSDump; delimiter (dumpDelimiter) is automatically added after each segment

}

void SSMInit() {
  SSMSerial.begin(SSMBAUDRATE, SERIAL_8N1, SSM_RX, SSM_TX); // meh..
}

