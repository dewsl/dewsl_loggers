/*
  Due_config.h - Library of configurations
  2024.02.01
*/

#ifndef Due_config_h
#define Due_config_h

#include "Arduino.h"

struct libConfig {
  const char* lib_mastername;
  const char* lib_column_ids;
  const uint8_t lib_num_of_nodes;
  const uint8_t lib_sensor_version;
  const uint8_t lib_datalogger_version;
  const uint8_t lib_has_piezo;
  const uint16_t lib_turn_on_delay;
  const uint16_t lib_broad_timeout;
  const uint8_t lib_sampling_max_retry;
  const uint8_t lib_b64;
};
extern const int lib_LOGGER_COUNT;
extern struct libConfig config_container[];
// 
#endif